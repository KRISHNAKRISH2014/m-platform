#	showcult.com

A Platform for the Movie Maniacs

* Install the dependencies

		npm install

* Seed the sample data into mongo, with DB url as specified in your `env` variable `SHOWCULTDB`.

		npm run import