module.exports = {
  db: process.env.SHOWCULTDB
};